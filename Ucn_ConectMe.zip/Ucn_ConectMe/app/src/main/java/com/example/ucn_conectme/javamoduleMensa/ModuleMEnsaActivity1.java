package com.example.ucn_conectme.javamoduleMensa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.ucn_conectme.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class ModuleMEnsaActivity1 extends AppCompatActivity {

    private CircleImageView ftperfil;
    private TextView lblnombre;
    private RecyclerView rvmensaje;
    private EditText txtmensaje;
    private Button btnenviar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_mensa1);
        ftperfil=(CircleImageView)findViewById(R.id.ftperfil);
        lblnombre=(TextView) findViewById(R.id.lblnombre);
        rvmensaje=(RecyclerView) findViewById(R.id.rbmensaje);
        txtmensaje=(EditText) findViewById(R.id.txtmensaje);
        btnenviar=(Button) findViewById(R.id.btnenviar);


    }
}